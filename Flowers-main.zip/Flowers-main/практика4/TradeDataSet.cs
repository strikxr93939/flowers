﻿namespace практика4
{


    partial class TradeDataSet
    {
    }
}
